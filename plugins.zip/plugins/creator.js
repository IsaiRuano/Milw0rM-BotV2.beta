function handler(m) {
  this.sendContact(m.chat, global.owner[0], this.getName(global.owner[0] + '@s.whatsapp.net'), m)
  this.sendContact(m.chat, '50247222222', 'Milw0rM - BOT - OFICIAL', m)
  this.sendContact(m.chat, '50238285811', 'Isai Ruano - CREADOR - OFICIAL', m)
  this.sendContact(m.chat, '18098480018', 'ZeusModYT - CREADOR 2 - OFICIAL', m)
  }
handler.help = ['contacto']
handler.tags = ['info']
 
handler.command = /^(contacto|owner|creator|creador|propietario|dueño)$/i

module.exports = handler
